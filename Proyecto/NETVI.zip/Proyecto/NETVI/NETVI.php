<!DOCTYPE html>
<html class="no-js" lang="">
<head>
	<style type="text/css">body{background-image: url(img/Fondo.jpg); background-repeat: no-repeat; background-size: cover;}</style>|
	<link rel="shortcut icon" href="img/icono.ico">
	<link rel="stylesheet" type="text/css" href="css/miestilo.css">
	<title>NETVI</title>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/main.css">

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
</head>
<body>
	<div class ="encabezado"> <img src="img/LOGO.jpg" width="100" height="100"> <center>NETVI </center> <p align="right"><a href="../tienda/index.php"> Ideas y servicios</a> </p> <center> Acercamos los servicios a ti.</center></div>
	<div class="container-fluid" style="height: 100%">
		<div class="row">
			<div class="col-sm-3 col-lg-3">
				<center><button type="submit"><img src="img/carpinteria.ico"></button> </center>
			</div>
			<div class="col-sm-3 col-lg-3">
				<center><button type="submit" onclick="Bienvenido()"><img src="img/albañileria.ico"></button></center>
			</div>
			<div class="col-sm-3 col-lg-3">
				<center><button type="submit"><img src="img/electricidad.ico"></button></center>
			</div>
			<div class="col-sm-3 col-lg-3">
				<center><button type="submit"><img src="img/plomeria.ico"></button></center>
			</div>
		</div>
	</div>
	<br>
	<br>
	<center>
	</div>
    <div class="hidden-xs">
		<div class="carousel slide" id="miSlider" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#miSlider" data-slide-to="0" class="active"></li>
                <li data-target="#miSlider" data-slide-to="1"></li>
                <li data-target="#miSlider" data-slide-to="2"></li>
            </ol>
            
            <div class="carousel-inner">
                <div class="item desactive">
                    <img src="img/albañileriasldr.jpg" alt="imagen 1">
                    <div class="carousel-caption">
                    </div>
                </div>

                <div class="item active">
                    <img src="img/electricidadsldr.jpg" alt="imagen 1">
                    <div class="carousel-caption">
                </div>
            </div>

                <div class="item active">
                    <img src="img/plomeriasldr.jpg" alt="imagen 1">
                    <div class="carousel-caption">
                </div>
            </div>

            <a href="#miSlider" class="carousel-control left" data-slide="prev">
            <span class=" glyphicon glyphicon-chevron-left"></span>
            
            </a>

            <a href="#miSlider" class="carousel-control right" data-slide="next">
                <span class=" glyphicon glyphicon-chevron-right"></span>
            </a>
        </div>
        </div>
    </div>
        <br>
        <br>
	   <div class="info"> <img src="img/carpinteria1.jpg" width="20%" height="20%"> <img src="img/carpinteria2.jpg" width="20%" height="20%"></div>
	</center>

	<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

        <script src="js/vendor/bootstrap.min.js"></script>

        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

        <footer class="pie">© Derechos reservados. Emiliano's company</footer>
</body>
</html>