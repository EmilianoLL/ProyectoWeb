# OnlineStore
Sistema o tienda en linea desarrollada con MySql, php, jQuery, Bootstrap y Ajax

# Datos de la cuenta del administrador
```
Usuario: admin
```
```
Clave: admin
```
# Video de la instalacion
[Ver en YouTube](https://www.youtube.com/watch?v=V_XVRfpqCyI)
